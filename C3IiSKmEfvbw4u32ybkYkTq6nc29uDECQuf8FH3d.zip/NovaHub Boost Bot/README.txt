* NovaHub's Boost Bot *
-----------------------

> Thank you for purchasing! This bot comes with various commands, such as /boost, /restock, /stock, /givetokens, /whitelist,  and /unwhitelist.
> This bot is for Windows only, doesn't work on Linux though you could try to modify it.

-----------------------

The benefit of this bot is that it can be sold as an SRC while also being licencable. You will do this through https://keyauth.cc/

Step 0) Make sure Python is installed from MS Store, I'm using Python 3.11
Step 0) Fill out config. Make sure bot has applications.commands and the intents (bottom 3 ones under bot category in dev portal)

Step 1) Go to the KeyAuth website and create an account

Step 2) Go to Manage Applications > Create App > Name it Boost Bot (or whatever you'd like)

Step 3) On App Credentials Code, click Python, then go to main.py and at Line 27 (or similar) under keyauthapp = api(, paste the code given from KeyAuth

Step 4) Go to Licences > Create Keys, and make yourself a lifetime one.

Step 5) Go back to your Boost Bot folder and type `cmd` in the file path. Then type `python main.py`
* you will most likely have to import modules. When the code errors out, type `pip install (module thats missing)`, so pip install discord for example
* make sure to also run `pip install pycord` and `pip install py-cord` even though they won't be missing

Step 6) Once your Boost Bot is loaded, type 2 and register a username and password with the licence key given from KeyAuth.

Step 7) Enjoy! You can now login and use the bot. Feel free to give out licences and resell this bot using the same process.

-----------------------

Feel free to open a ticket for support! We ask that you write a vouch to receive updates/support with this tool. Thanks for purchasing! We appreciate your service greatly.

+rep @1116106906784780499 1x Boost Bot, (add comment) (rate service out of 10)
example: +rep @1116106906784780499 1x Boost Bot, legit and good tool 10/10